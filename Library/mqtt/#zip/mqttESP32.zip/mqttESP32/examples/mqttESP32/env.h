#ifndef ENV_H
#define ENV_H
const char *ssid = "";
const char *pw = "";
#endif